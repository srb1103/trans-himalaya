"use strict";
exports.id = 452;
exports.ids = [452];
exports.modules = {

/***/ 1042:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ Alert),
/* harmony export */   j: () => (/* binding */ Error)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function Alert(props) {
    let { status, title, message, bsClose } = props;
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        document.querySelector("body").classList.add("noscroll");
    }, []);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bs_bg flex jcc",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "bs_container",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "bs_head",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            children: title
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: bsClose,
                            className: "bsClose",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                name: "close-outline"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `bs_wrp flex jcc fdc ${status}`,
                    children: [
                        status == "success" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                            name: "checkmark-outline"
                        }) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                            name: "close-outline"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            className: `hero_p`,
                            children: message
                        })
                    ]
                })
            ]
        })
    });
}
function Error(props) {
    let { fun, text } = props;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "error_wrap",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                className: "error_text",
                children: text
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                onClick: fun,
                className: "errClose",
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                    name: "close-outline"
                })
            })
        ]
    });
}


/***/ }),

/***/ 6422:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ Foot)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function Foot() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("script", {
            type: "module",
            src: "https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js",
            async: true
        })
    });
}


/***/ }),

/***/ 7623:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ Footer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);



function Footer() {
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: "wwd_section flex jcc fdc footer",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "ftop_section",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "ftop",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: "/logo.png",
                                height: 40,
                                width: 800,
                                alt: "Trans Himalayas Travels",
                                className: "logo"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "hero_p",
                                children: "At TransHimalayas, we‘re not just experts in Himachal Pradesh; we‘re your dedicated guides to the pristine landscapes of Shimla, the adventures of Manali, the serenity of Kullu, the mystique of Spiti, and beyond."
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                href: "tel:+918091066115",
                                className: "btn btn-pri",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                        name: "call"
                                    }),
                                    " Call Now"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                href: "https://wa.me/918091066115",
                                target: "_blank",
                                className: "btn btn-sec",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                        name: "logo-whatsapp"
                                    }),
                                    " WhatsApp Us"
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "hero_p",
                                children: [
                                    "For More Queries",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "mailto:contact@transhimalayatravels.in",
                                        children: "contact@transhimalayatravels.in"
                                    }),
                                    " | ",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        href: "tel:+918091066115",
                                        children: "+91 80910 66115"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "ftop flex jcc fdc",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: "/ratings.png",
                                height: 80,
                                width: 300,
                                alt: "Trans Himalayas Travels",
                                className: "ftopimg"
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "ftr_links flex jcc",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "ftr_li",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: "https://transhimalayatravels.in/about/",
                                            className: "ftr_lia",
                                            children: "About Us"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "ftr_li",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: "https://transhimalayatravels.in/blog/",
                                            className: "ftr_lia",
                                            children: "Blog"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "ftr_li",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: "https://transhimalayatravels.in/privacy-policy/",
                                            className: "ftr_lia",
                                            children: "Privacy Policy"
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "ftr_li",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: "https://transhimalayatravels.in/terms-conditions/",
                                            className: "ftr_lia",
                                            children: "Terms & Conditions"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: "ftr_links flex jcc",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "ftr_li",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: "#",
                                            className: "ftr_lia",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                                name: "logo-facebook"
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "ftr_li",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: "#",
                                            className: "ftr_lia",
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                                name: "logo-instagram"
                                            })
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "line"
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "ftop_section",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "ftop",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                className: "hero_p",
                                children: "Trans Himalayas \xa9 2023. All Rights Reserved."
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                className: "hero_p",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Office Address"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "Top floor, Verma building,",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "Bhatakuffer bypass, Sanjauli,",
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                                    "Shimla - H.P - 171006"
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "ftop flex jcc fdc",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                            src: "/govt.png",
                            height: 60,
                            width: 400,
                            alt: "Verified By",
                            className: "ftopimg"
                        })
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 4487:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   p: () => (/* binding */ CallForm),
/* harmony export */   y: () => (/* binding */ QueryForm)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _InputBox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(4170);
/* harmony import */ var _Alert__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1042);
/* harmony import */ var js_cookie__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(9915);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([js_cookie__WEBPACK_IMPORTED_MODULE_4__]);
js_cookie__WEBPACK_IMPORTED_MODULE_4__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const stateReducer = (state, action)=>{
    switch(action.type){
        case "UPDATE":
            let { name, value } = action;
            return {
                ...state,
                [name]: value
            };
        default:
            return state;
    }
};
function QueryForm(props) {
    const { bsClose, save, pack } = props;
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [btnText, setBtnText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Send Query");
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [error_message, setError_message] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        document.querySelector("body").classList.add("noscroll");
    }, []);
    const [state, dispatchState] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(stateReducer, {
        name: "",
        phone: "",
        destination: "",
        mode: "call"
    });
    const handleChange = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((name, value)=>{
        dispatchState({
            type: "UPDATE",
            name,
            value
        });
    }, [
        dispatchState
    ]);
    let options = [
        {
            id: "call",
            name: "Call"
        },
        {
            id: "whatsapp",
            name: "WhatsApp"
        }
    ];
    async function handleSubmit(event) {
        event.preventDefault();
        let { name, phone, destination, mode } = state;
        let er = "";
        if (!mode) {
            er = "Please select preferred mode of communication.";
        }
        if (!phone) {
            er = "Please enter your contact number.";
        }
        if (!name) {
            er = "Please enter your name.";
        }
        if (er) {
            setError(true);
            setError_message(er);
        } else {
            setLoading(true);
            setBtnText("Sending...");
            let url = pack ? `https://api.emezy.in/tht/api?type=package_query&name=${name}&contact=${phone}&mode=${mode}&package=${pack}` : `https://api.emezy.in/tht/api?type=general_query&name=${name}&contact=${phone}&mode=${mode}&destination=${destination}`;
            let res = await fetch(url);
            let status = res.status;
            if (status == 200) {
                js_cookie__WEBPACK_IMPORTED_MODULE_4__["default"].set("name", name);
                save();
            } else {
                setError(true);
                setError_message("Something went wrong. Please try again.");
                setLoading(false);
                setBtnText("Send Query");
            }
        }
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bs_bg flex jcc",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "bs_container",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "bs_head",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            children: "Send a Query"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Your personal details are kept private and used for consultation only."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: bsClose,
                            className: "bsClose",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                name: "close-outline"
                            })
                        })
                    ]
                }),
                error && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Alert__WEBPACK_IMPORTED_MODULE_3__/* .Error */ .j, {
                    fun: ()=>setError(false),
                    text: error_message
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                    className: "form_container flex jcc fdc",
                    onSubmit: handleSubmit,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "form_grid",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InputBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    fun: handleChange,
                                    label: "Name",
                                    placeholder: "Enter your name",
                                    val: state.name,
                                    required: "required",
                                    name: "name"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InputBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    fun: handleChange,
                                    label: "Contact Number",
                                    placeholder: "Enter contact number",
                                    val: state.phone,
                                    required: "required",
                                    name: "phone",
                                    type: "phone",
                                    pattern: "[6789][0-9]{9}"
                                }),
                                !pack && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InputBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    fun: handleChange,
                                    label: "Destination",
                                    placeholder: "Enter destination",
                                    val: state.destination,
                                    name: "destination"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InputBox__WEBPACK_IMPORTED_MODULE_2__/* .SelectInput */ .l, {
                                    fun: handleChange,
                                    label: "Communication Mode",
                                    val: state.mode,
                                    name: "mode",
                                    options: options,
                                    required: true,
                                    firstTitle: "Select Preferred Communication Mode",
                                    disabled: "disabled"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "btn btn-pri",
                            disabled: loading,
                            children: btnText
                        })
                    ]
                })
            ]
        })
    });
}
function CallForm(props) {
    const { bsClose, save } = props;
    const [loading, setLoading] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [btnText, setBtnText] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)("Book Now");
    const [error, setError] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const [error_message, setError_message] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        document.querySelector("body").classList.add("noscroll");
    }, []);
    const [state, dispatchState] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(stateReducer, {
        name: "",
        phone: ""
    });
    const handleChange = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)((name, value)=>{
        dispatchState({
            type: "UPDATE",
            name,
            value
        });
    }, [
        dispatchState
    ]);
    async function handleSubmit(event) {
        event.preventDefault();
        let { name, phone } = state;
        let er = "";
        if (!phone) {
            er = "Please enter your contact number.";
        }
        if (!name) {
            er = "Please enter your name.";
        }
        if (er) {
            setError(true);
            setError_message(er);
        } else {
            setLoading(true);
            setBtnText("Please wait...");
            let res = await fetch(`https://api.emezy.in/tht/api?type=call_booking&name=${name}&contact=${phone}`);
            let status = res.status;
            if (status == 200) {
                js_cookie__WEBPACK_IMPORTED_MODULE_4__["default"].set("name", name);
                save();
            } else {
                setError(true);
                setError_message("Something went wrong. Please try again.");
                setLoading(false);
                setBtnText("Book Now");
            }
        }
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: "bs_bg flex jcc",
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "bs_container",
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: "bs_head",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                            children: "Book a Query"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Your personal details are kept private and used for consultation only."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: bsClose,
                            className: "bsClose",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                name: "close-outline"
                            })
                        })
                    ]
                }),
                error && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Alert__WEBPACK_IMPORTED_MODULE_3__/* .Error */ .j, {
                    fun: ()=>setError(false),
                    text: error_message
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                    className: "form_container flex jcc fdc",
                    onSubmit: handleSubmit,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: "form_grid",
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InputBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    fun: handleChange,
                                    label: "Name",
                                    placeholder: "Enter your name",
                                    val: state.name,
                                    required: "required",
                                    name: "name"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_InputBox__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {
                                    fun: handleChange,
                                    label: "Contact Number",
                                    placeholder: "Enter contact number",
                                    val: state.phone,
                                    required: "required",
                                    name: "phone",
                                    type: "phone",
                                    pattern: "[6789][0-9]{9}"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "btn btn-pri",
                            disabled: loading,
                            children: btnText
                        })
                    ]
                })
            ]
        })
    });
}

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4170:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ InputBox),
/* harmony export */   l: () => (/* binding */ SelectInput)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);


function InputBox(props) {
    let { type, placeholder, required, val, fun, label, name, id, pattern } = props;
    let [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(val ? val : "");
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setValue(val);
    }, [
        val
    ]);
    const handleChange = (event)=>{
        let txt = event.target.value;
        setValue(txt);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        fun(name, value);
    }, [
        name,
        value,
        fun
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: "inputGrp",
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                    className: "form_label",
                    children: label
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                    type: type ? type : "text",
                    required: required,
                    placeholder: placeholder,
                    className: "form_input",
                    value: value,
                    onChange: handleChange,
                    min: "0",
                    id: id ? name : null,
                    autoComplete: "off",
                    pattern: pattern ? pattern : null
                })
            ]
        })
    });
}
function SelectInput(props) {
    let { options, label, sel, placeholder, firstTitle, fun, required, name, disabled, class_name, title, id } = props;
    let [value, setValue] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(sel ? sel : "");
    const handleSelect = (event)=>{
        let txt = event.target.value;
        setValue(txt);
    };
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setValue(sel);
    }, [
        sel
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        fun(name, value);
    }, [
        name,
        value,
        fun
    ]);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "inputGrp",
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                className: "form_label",
                children: label
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                required: required,
                placeholder: placeholder,
                className: `form_input ${class_name}`,
                onChange: handleSelect,
                title: title ? title : "",
                id: id ? name : null,
                value: value,
                children: [
                    firstTitle && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                        value: "",
                        disabled: disabled,
                        children: firstTitle
                    }),
                    options.map((option)=>{
                        let { id, name } = option;
                        return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                            value: id,
                            children: name
                        }, id);
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 5600:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ NavBar)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_3__);




function NavBar() {
    function toggleMenu() {
        document.querySelector("nav").classList.toggle("show");
        document.querySelector("body").classList.toggle("noscroll");
    }
    function removeShow() {
        document.querySelector("nav").classList.remove("show");
        document.querySelector("body").classList.toggle("noscroll");
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("noscript", {
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("iframe", {
                    src: "https://www.googletagmanager.com/ns.html?id=GTM-NXV64GG",
                    height: "0",
                    width: "0",
                    style: {
                        display: "none"
                    }
                })
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                className: `nav flex jcc`,
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: `navContent flex jcsb`,
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: "/logo.png",
                                height: 40,
                                width: 500,
                                alt: "Trans Himalayas Travels",
                                className: "logo"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: `navUlWrap flex`,
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                className: `navUL flex`,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                        className: "navLi btn",
                                        children: [
                                            "Packages ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                                name: "chevron-down-outline"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                                                className: "navSUL",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "navSLI",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                            href: "/packages/budget",
                                                            onClick: removeShow,
                                                            children: "Budget Ideas"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "navSLI",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                            href: "/packages/family",
                                                            onClick: removeShow,
                                                            children: "Family Holidays"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "navSLI",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                            href: "/packages/group",
                                                            onClick: removeShow,
                                                            children: "Group Tours"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "navSLI",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                            href: "/packages/honeymoon",
                                                            onClick: removeShow,
                                                            children: "Honeymoon Tours"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "navSLI",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                            href: "/packages/luxury",
                                                            onClick: removeShow,
                                                            children: "Luxury Holidays"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                                        className: "navSLI",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_3___default()), {
                                                            href: "/packages/trek",
                                                            onClick: removeShow,
                                                            children: "Treks & Adventures"
                                                        })
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                        className: "navLi btn",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                            href: "https://transhimalayatravels.in/offer/offer/",
                                            target: "_blank",
                                            children: "Special Offers"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: "flex jcc",
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                href: "tel:+918091066115",
                                                className: "btn btn-pri",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                                        name: "call"
                                                    }),
                                                    " Call Now"
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("a", {
                                                href: "https://wa.me/918091066115",
                                                target: "_blank",
                                                className: "btn btn-sec",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                                        name: "logo-whatsapp"
                                                    }),
                                                    " WhatsApp Us"
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            onClick: toggleMenu,
                            className: "menuToggle",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                name: "menu-outline"
                            })
                        })
                    ]
                })
            })
        ]
    });
}


/***/ }),

/***/ 2884:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Z: () => (/* binding */ Package)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(5893);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);



function Package(props) {
    let { img, name, location, cost, duration, fun } = props;
    let dur = `${duration - 1} Nights / ${duration} Days`;
    function setNum(num) {
        let n = parseInt(num);
        n = n.toLocaleString("en-IN");
        return n;
    }
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        className: "package",
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pack_img_wrap",
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                        src: img,
                        height: 100,
                        width: 1000,
                        className: "pack_img",
                        alt: name
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "pack_ovr",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                                className: "pack_name",
                                children: name
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                                className: "pack_dur",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                        name: "time-outline"
                                    }),
                                    " ",
                                    dur
                                ]
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: "pack_det",
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("span", {
                        className: "pc_price",
                        children: [
                            "₹ ",
                            setNum(cost)
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                        className: "pack_name dsts",
                        children: "Places Covered"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ul", {
                        className: "dstUl",
                        children: location.map((d, ind)=>/*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                className: "dstLi",
                                children: d
                            }, ind.toString()))
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "line"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                        className: "plnd_ul flex jcsb",
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "plnd_li",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                        name: "bed-outline"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: "Hotels"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "plnd_li",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                        name: "telescope-outline"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: "Sightseeing"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "plnd_li",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                        name: "fast-food-outline"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: "Meals"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                className: "plnd_li",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("ion-icon", {
                                        name: "car-sport-outline"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                        children: "Transfers"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "line"
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("center", {
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "btn btn-pri",
                            onClick: ()=>fun(name),
                            children: "Get Free Quotes"
                        })
                    })
                ]
            })
        ]
    });
}


/***/ }),

/***/ 5633:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   B: () => (/* binding */ packages)
/* harmony export */ });
/* unused harmony export home_page_url */
const packages = [
    {
        name: "Beautiful mcleodganj weekend",
        location: [
            "Dharamshala",
            "Mcleaodganj"
        ],
        duration: 4,
        cost: 699,
        category: [
            "weekend",
            "budget"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/5-1.png"
    },
    {
        name: "Spiti circuit, Group tour 2023",
        location: [
            "Kinnaur",
            "Tabo",
            "Pin",
            "Chandratal"
        ],
        duration: 11,
        cost: 22500,
        category: [
            "group",
            "trek"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/5-1.png"
    },
    {
        name: "Spiti in Summer – Group tour 2023",
        location: [
            "Chandratal",
            "Tabo",
            "Kaza"
        ],
        duration: 7,
        cost: 16500,
        category: [
            "group",
            "trek"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Unexposed-Chanshal-valley-trek-and-tour-package-2.png"
    },
    {
        name: "Spiti in Spring",
        location: [
            "Chitkul",
            "Nako",
            "Tabo",
            "Kaza"
        ],
        duration: 9,
        cost: 17900,
        category: [
            "group"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Spiti-in-Spring.jpg"
    },
    {
        name: "Mesmerizing weekend escaper to Prasher Lake",
        location: [
            "Mandi",
            "Prasher"
        ],
        duration: 4,
        cost: 5499,
        category: [
            "budget"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Mesmerising-weekend-escaper-to-Prasher-Lake-trek-2.png"
    },
    {
        name: "Explore Seolsar Lake trek and Tirthan valley",
        location: [
            "Manali",
            "Tirthan"
        ],
        duration: 3,
        cost: 6599,
        category: [
            "budget"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Explore-Seolsar-Lake-trek-and-Tirthan-valley-1-1.png"
    },
    {
        name: "Breathtaking Khajjiar & Dalhousie",
        location: [
            "Dalhousie",
            "Khajjiar"
        ],
        duration: 4,
        cost: 7499,
        category: [
            "budget"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Dharamshala-and-dalhousie-22.png"
    },
    {
        name: "Manali holiday package tour",
        location: [
            "Manali",
            "Kasol",
            "Kullu"
        ],
        duration: 5,
        cost: 10500,
        category: [
            "budget"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Manali-tour-package-from-Delhi.png"
    },
    {
        name: "Manali tour package from Delhi",
        location: [
            "Manali",
            "Naggar",
            "Kullu"
        ],
        duration: 4,
        cost: 4999,
        category: [
            "budget"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Manali-holiday-package-tour.png"
    },
    {
        name: "Best selling Shimla & Manali tour package",
        location: [
            "Manali",
            "Shimla",
            "Solang Velley"
        ],
        duration: 7,
        cost: 10500,
        category: [
            "budget"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Best-Selling-Shimla-Manali-Tour-Package.png"
    },
    {
        name: "Splended Shimla Manali tour",
        location: [
            "Manali",
            "Shimla",
            "Kullu"
        ],
        duration: 6,
        cost: 9900,
        category: [
            "budget"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Splended-Shimla-Manali-tour-from-Delhi.png"
    },
    {
        name: "Incredible road trip to leh ladakh",
        location: [
            "Leh",
            "Nubra",
            "Pangong"
        ],
        duration: 11,
        cost: 32500,
        category: [
            "family"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Incredible-road-trip-to-leh-ladakh.png"
    },
    {
        name: "Sensational leh ladakh tour package",
        location: [
            "Leh",
            "Nubra",
            "Pangong"
        ],
        duration: 9,
        cost: 32500,
        category: [
            "family"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Sensational-leh-ladakh-tour-package.png"
    },
    {
        name: "Shaktipeeth darshan in Himachal",
        location: [
            "Chandigarh",
            "Kangra"
        ],
        duration: 5,
        cost: 26900,
        category: [
            "family"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Shaktipeeth-darshan-in-Himachal.png"
    },
    {
        name: "Family tour package for Himachal Pradesh",
        location: [
            "Shimla",
            "Manali",
            "Dharamshala",
            "Dalhousie"
        ],
        duration: 10,
        cost: 20500,
        category: [
            "family",
            "honeymoon",
            "luxury"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Family-tour-package-for-himachal-pradesh-1.png"
    },
    {
        name: "Mesmerizing Dharamshala & Dalhousie",
        location: [
            "Dharamshala",
            "Mcleodganj",
            "Khajjiar"
        ],
        duration: 6,
        cost: 19500,
        category: [
            "family",
            "honeymoon"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/4-1.png"
    },
    {
        name: "Delightful golden triangle tour package",
        location: [
            "Delhi",
            "Agra",
            "Jaipur"
        ],
        duration: 6,
        cost: 24900,
        category: [
            "honeymoon",
            "luxury"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Delightful-golden-triangle-tour-package.png"
    },
    {
        name: "Charming Delhi Agra Jaipur tour package",
        location: [
            "Delhi",
            "Agra",
            "Jaipur"
        ],
        duration: 6,
        cost: 24900,
        category: [
            "honeymoon",
            "luxury"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Charming-Delhi-Agra-Jaipur-tour-package.png"
    },
    {
        name: "Romantic Shimla Manali luxury package",
        location: [
            "Shimla",
            "Kullu",
            "Manali"
        ],
        duration: 6,
        cost: 35000,
        category: [
            "honeymoon",
            "luxury"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Romantic-Shimla-Manali-Luxury-Package.png"
    },
    {
        name: "Splendid Shimla & Kullu-Manali with Chandigarh",
        location: [
            "Shimla",
            "Kullu",
            "Manali",
            "Chandigarh"
        ],
        duration: 7,
        cost: 43000,
        category: [
            "luxury"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Splendid-Shimla-Kullu-Manali-from-Chandigarh.png"
    },
    {
        name: "Exciting Chandernahan lake trek package",
        location: [
            "Rohru",
            "Chandernahan"
        ],
        duration: 6,
        cost: 11500,
        category: [
            "trek"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Exciting-Chandernahan-lake-trek-package-1.png"
    },
    {
        name: "Inspiring Beas Kund trek",
        location: [
            "Solang",
            "Manali",
            "Beas Kund"
        ],
        duration: 3,
        cost: 6500,
        category: [
            "trek"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Inspiring-Beas-Kund-trek-1.png"
    },
    {
        name: "Adventurous Hampta pass trek",
        location: [
            "Manali",
            "Hampta",
            "Chandratal"
        ],
        duration: 5,
        cost: 13500,
        category: [
            "trek"
        ],
        img: "https://transhimalayatravels.in/wp-content/uploads/2022/12/Adventurous-Hampta-pass-trek-1.png"
    }
];
const home_page_url = "https://transhimalayatravels.in/wp-content/uploads/2023/03/Brown-Business-Guarantee-Instagram-Post-banner.jpg";


/***/ })

};
;