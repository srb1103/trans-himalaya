import React from 'react'

export default function Foot() {
  return (
    <>
<script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.esm.js" async/>
    </>
  )
}
